/* ***********************************************
	Strategy : Naked Pair 
*********************************************** */
var oStgNakedPair = new NodeObject();

oStgNakedPair.onsolverequest = function(oSr){
	var oPz = oSr.puzzle;
	var oUr = new UpdateRequest(UR_NONE, oPz);
	var aMsgs = [];
	
	var apLu = null;
	var iAd = 0, iAd1 = 0, iAd2 = 0;
	var iFt = 0, iFtCup = 0;
	var aBivalued = null;
	var oMsg = null;
	// Loop for mode : row / column / box
	for (var iMode = 0; 3 > iMode; iMode++){
		// Loop for each logical unit in the given mod
		for (var iPtrLu = 0; SDK_ORDER > iPtrLu; iPtrLu++){
			switch (iMode){
				case 0 :
				apLu = LU_ROW_DATA[iPtrLu];
				break;
				case 1 :
				apLu = LU_COL_DATA[iPtrLu];
				break;
				case 2 :
				apLu = LU_BOX_DATA[iPtrLu];
				break;
			}
			// Create a list of bi-valued cells
			aBivalued = [];
			for (var iPtr = 0; SDK_ORDER > iPtr; iPtr++){
				if (oPz.cell[apLu[iPtr]].size == 2){
					aBivalued.push(apLu[iPtr]);
				}
			}
			// Loop for the first bi-valued cell
			for (var iPtr1 = 0; aBivalued.length > iPtr1; iPtr1++){
				iFt = oPz.data[iAd1 = aBivalued[iPtr1]]; // common candidate set
				// Loop for the second bi-valued cell
				for (var iPtr2 = iPtr1+1; aBivalued.length > iPtr2; iPtr2++){
					if (iFt != oPz.data[iAd2 = aBivalued[iPtr2]]){
						continue;
					}
					// If two cells match the naked pair condition
					// Loop for the elimination
					oMsg = {
						basis : [{ mode : iMode, pointer : iPtrLu }], 
						candi1 : new Candi(iAd1, oPz.data[iAd1]),
						candi2 : new Candi(iAd2, oPz.data[iAd2]),
						removed : []
					};
					for (var iPtr = 0; SDK_ORDER > iPtr; iPtr++){
						// skip the pair
						iAd = apLu[iPtr];
						if (iAd1 == iAd || iAd2 == iAd){
							continue;
						}
						// if the cell shares a common candidate with the pair
						if (iFtCup = iFt & oPz.data[iAd]){
							oMsg.removed.push(new Candi(iAd, iFtCup));
						}
					} // End of Loop : elimination
					if (oMsg.removed.length){
						var bExists = false;
						for (var iM = 0; aMsgs.length > iM; iM++){
							if (aMsgs[iM].candi1.ad == iAd1 && aMsgs[iM].candi2.ad == iAd2){
								bExists = true;
								aMsgs[iM].basis.push(oMsg.basis[0]);
								add_next :
								for (var iL = 0; oMsg.removed.length > iL; iL++){
									for (var iK = 0; aMsgs[iM].removed.length > iK; iK++){
										if (oMsg.removed[iL].ad == aMsgs[iM].removed[iK].ad){
											continue add_next;
										}
									}
									aMsgs[iM].removed.push(oMsg.removed[iL]);
								}
								break;
							}
						}
						if (!bExists){
							aMsgs.push(oMsg);
						}
					}
				} // End of Loop : 2nd bi-valued cell
			} // End of Loop : 1st bi-valued cell
		} // End of Loop : logical unit
	} // End of Loop : mode

	if (aMsgs.length){
		oUr.type = UR_NAKED2;
		oUr.messages = aMsgs;
		oUr.action = this.actionDetermine;
	}
	this.parent.updaterequest(oUr);
	return false;
};

oStgNakedPair.actionDetermine = function(){
	var oPz = this.puzzle;
	var aRemoved;
	for (var iN = 0; this.messages.length > iN; iN++){
		aRemoved = this.messages[iN].removed;
		for (var iM = 0; aRemoved.length > iM; iM++){
			oPz.data[aRemoved[iM].ad] &= ~aRemoved[iM].candi;
			oPz.cell[aRemoved[iM].ad].update(true);
		}
	}
};

/* ***********************************************
	Strategy : Naked Triple 
*********************************************** */
var oStgNakedTriple = new NodeObject();

oStgNakedTriple.onsolverequest = function(oSr){
	var oPz = oSr.puzzle;
	var oUr = new UpdateRequest(UR_NONE, oPz);
	var aMsgs = [];
	
	var apLu = null;
	var iAd = 0, iAd1 = 0, iAd2 = 0, iAd3 = 0;
	var iFt = 0, iFt1 = 0, iFt2 = 0, iFt3 = 0, iFtCup = 0;
	var aTrivalued = null;
	var oMsg = null;
	// Loop for mode : row / column / box
	for (var iMode = 0; 3 > iMode; iMode++){
		// Loop for each logical unit in the given mod
		for (var iPtrLu = 0; SDK_ORDER > iPtrLu; iPtrLu++){
			switch (iMode){
				case 0 :
				apLu = LU_ROW_DATA[iPtrLu];
				break;
				case 1 :
				apLu = LU_COL_DATA[iPtrLu];
				break;
				case 2 :
				apLu = LU_BOX_DATA[iPtrLu];
				break;
			}
			// Create a list of bi-valued cells
			aTrivalued = [];
			for (var iPtr = 0; SDK_ORDER > iPtr; iPtr++){
				iAd = apLu[iPtr];
				if (oPz.cell[iAd].size == 2 || oPz.cell[iAd].size == 3){
					aTrivalued.push(iAd);
				}
			}
			// Loop for the first bi-valued cell
			for (var iPtr1 = 0; aTrivalued.length > iPtr1; iPtr1++){
				iFt1 = oPz.data[iAd1 = aTrivalued[iPtr1]]; // common candidate set
				// Loop for the second tri-valued cell
				for (var iPtr2 = iPtr1+1; aTrivalued.length > iPtr2; iPtr2++){
					iFt2 = iFt1 | oPz.data[iAd2 = aTrivalued[iPtr2]]; // common candidate set
					if (_size(iFt2) > 3){
						continue;
					}
					// Loop for the third tri-valued cell
					for (var iPtr3 = iPtr2+1; aTrivalued.length > iPtr3; iPtr3++){
						iFt3 = iFt2 | oPz.data[iAd3 = aTrivalued[iPtr3]]; // common candidate set
						if (_size(iFt3) > 3){
							continue;
						}
						// If two cells match the naked triple condition
						// Loop for the elimination
						oMsg = {
							basis : [{ mode : iMode, pointer : iPtrLu }], 
							candi1 : new Candi(iAd1, oPz.data[iAd1]),
							candi2 : new Candi(iAd2, oPz.data[iAd2]),
							candi3 : new Candi(iAd3, oPz.data[iAd3]),
							removed : []
						};
						for (var iPtr = 0; SDK_ORDER > iPtr; iPtr++){
							// skip the triple
							iAd = apLu[iPtr];
							if (iAd1 == iAd || iAd2 == iAd || iAd3 == iAd){
								continue;
							}
							// if the cell shares a common candidate with the pair
							if (iFtCup = iFt3 & oPz.data[iAd]){
								oMsg.removed.push(new Candi(iAd, iFtCup));
							}
						} // End of Loop : elimination
						if (oMsg.removed.length){
							var bExists = false;
							for (var iM = 0; aMsgs.length > iM; iM++){
								if (aMsgs[iM].candi1.ad == iAd1
									&& aMsgs[iM].candi2.ad == iAd2
									&& aMsgs[iM].candi3.ad == iAd3){
									bExists = true;
									aMsgs[iM].basis.push(oMsg.basis[0]);
									add_next :
									for (var iL = 0; oMsg.removed.length > iL; iL++){
										for (var iK = 0; aMsgs[iM].removed.length > iK; iK++){
											if (oMsg.removed[iL].ad == aMsgs[iM].removed[iK].ad){
												continue add_next;
											}
										}
										aMsgs[iM].removed.push(oMsg.removed[iL]);
									}
									break;
								}
							}
							if (!bExists){
								aMsgs.push(oMsg);
							}
						}
					} // End of Loop : 3rd tri-valued cell
				} // End of Loop : 2nd tri-valued cell
			} // End of Loop : 1st tri-valued cell
		} // End of Loop : logical unit
	} // End of Loop : mode

	if (aMsgs.length){
		oUr.type = UR_NAKED3;
		oUr.messages = aMsgs;
		oUr.action = this.actionDetermine;
	}
	this.parent.updaterequest(oUr);
	return false;
};

oStgNakedTriple.actionDetermine = function(){
	var oPz = this.puzzle;
	var aRemoved;
	for (var iN = 0; this.messages.length > iN; iN++){
		aRemoved = this.messages[iN].removed;
		for (var iM = 0; aRemoved.length > iM; iM++){
			oPz.data[aRemoved[iM].ad] &= ~aRemoved[iM].candi;
			oPz.cell[aRemoved[iM].ad].update(true);
		}
	}
};

/* ***********************************************
	Strategy : Naked Quadraple 
*********************************************** */
var oStgNakedQuadraple = new NodeObject();

oStgNakedQuadraple.onsolverequest = function(oSr){
	var oPz = oSr.puzzle;
	var oUr = new UpdateRequest(UR_NONE, oPz);
	var aMsgs = [];

	// Loop for mode : row / column / box
	for (var iMode = 0; 3 > iMode; iMode++){
		// Loop for each logical unit in the given mod
		for (var iPtrLu = 0; SDK_ORDER > iPtrLu; iPtrLu++){
			var apLu;
			switch (iMode){
				case 0 :
				apLu = LU_ROW_DATA[iPtrLu];
				break;
				case 1 :
				apLu = LU_COL_DATA[iPtrLu];
				break;
				case 2 :
				apLu = LU_BOX_DATA[iPtrLu];
				break;
			}
			// Create a list of bi-valued cells
			var aQuadvalued = [];
			for (var iPtr = 0; SDK_ORDER > iPtr; iPtr++){
				var iAd = apLu[iPtr];
				if (oPz.cell[iAd].size == 2 || oPz.cell[iAd].size == 3 || oPz.cell[iAd].size == 4){
					aQuadvalued.push(iAd);
				}
			}
			// Loop for the first quad-valued cell
			for (var iPtr1 = 0; aQuadvalued.length > iPtr1; iPtr1++){
				var iAd1 = aQuadvalued[iPtr1];
				var iFt1 = oPz.data[iAd1]; // common candidate set
				// Loop for the second quad-valued cell
				for (var iPtr2 = iPtr1+1; aQuadvalued.length > iPtr2; iPtr2++){
					var iAd2 = aQuadvalued[iPtr2];
					var iFt2 = iFt1 | oPz.data[iAd2]; // common candidate set
					if (_size(iFt2) > 4){
						continue;
					}
					// Loop for the third quad-valued cell
					for (var iPtr3 = iPtr2+1; aQuadvalued.length > iPtr3; iPtr3++){
						var iAd3 = aQuadvalued[iPtr3];
						var iFt3 = iFt2 | oPz.data[iAd3]; // common candidate set
						if (_size(iFt3) > 4){
							continue;
						}
						// Loop for the third quad-valued cell
						for (var iPtr4 = iPtr3+1; aQuadvalued.length > iPtr4; iPtr4++){
							var iAd4 = aQuadvalued[iPtr4];
							var iFt4 = iFt3 | oPz.data[iAd4]; // common candidate set
							if (_size(iFt4) > 4){
								continue;
							}
							// If two cells match the naked triple condition
							// Loop for the elimination
							var oMsg = {
								basis : [{ mode : iMode, pointer : iPtrLu }], 
								candi1 : new Candi(iAd1, oPz.data[iAd1]),
								candi2 : new Candi(iAd2, oPz.data[iAd2]),
								candi3 : new Candi(iAd3, oPz.data[iAd3]),
								candi4 : new Candi(iAd4, oPz.data[iAd4]),
								removed : []
							};
							for (var iPtr = 0; SDK_ORDER > iPtr; iPtr++){
								// skip the triple
								var iAd = apLu[iPtr];
								if (iAd1 == iAd || iAd2 == iAd || iAd3 == iAd || iAd4 == iAd){
									continue;
								}
								// if the cell shares a common candidate with the pair
								var iFtCup = iFt4 & oPz.data[iAd];
								if (iFtCup){
									oMsg.removed.push(new Candi(iAd, iFtCup));
								}
							} // End of Loop : elimination
							if (oMsg.removed.length){
								var bExists = false;
								for (var iM = 0; aMsgs.length > iM; iM++){
									if (aMsgs[iM].candi1.ad == iAd1
										&& aMsgs[iM].candi2.ad == iAd2
										&& aMsgs[iM].candi3.ad == iAd3
										&& aMsgs[iM].candi4.ad == iAd4){
										bExists = true;
										aMsgs[iM].basis.push(oMsg.basis[0]);
										add_next :
										for (var iL = 0; oMsg.removed.length > iL; iL++){
											for (var iK = 0; aMsgs[iM].removed.length > iK; iK++){
												if (oMsg.removed[iL].ad == aMsgs[iM].removed[iK].ad){
													continue add_next;
												}
											}
											aMsgs[iM].removed.push(oMsg.removed[iL]);
										}
										break;
									}
								}
								if (!bExists){
									aMsgs.push(oMsg);
								}
							}
						} // End of Loop : 4th quad-valued cell
					} // End of Loop : 3rd quad-valued cell
				} // End of Loop : 2nd quad-valued cell
			} // End of Loop : 1st quad-valued cell
		} // End of Loop : logical unit
	} // End of Loop : mode

	if (aMsgs.length){
		oUr.type = UR_NAKED4;
		oUr.messages = aMsgs;
		oUr.action = this.actionDetermine;
	}
	this.parent.updaterequest(oUr);
	return false;
};

oStgNakedQuadraple.actionDetermine = function(){
	var oPz = this.puzzle;
	var aRemoved;
	for (var iN = 0; this.messages.length > iN; iN++){
		aRemoved = this.messages[iN].removed;
		for (var iM = 0; aRemoved.length > iM; iM++){
			oPz.data[aRemoved[iM].ad] &= ~aRemoved[iM].candi;
			oPz.cell[aRemoved[iM].ad].update(true);
		}
	}
};

/*
	Old Interface
*/

		case UR_NAKED2:
			if (oUr.inform){
				this.printer.append($("<div>").addClass("stg_title").text("Step #" + this.step + " : Naked Pair"));
				this.printer.newline();
				var oMsg;
				var aRemoved;
				for (var iN = 0; oUr.messages.length > iN; iN++){
					oMsg = oUr.messages[iN];
					this.printer.write(_candistr(oMsg.candi1.candi | oMsg.candi2.candi)
						 + "@[" + oMsg.candi1.adstr() + "|" + oMsg.candi2.adstr() + "]");
					for (var iM = 0; oMsg.basis.length > iM; iM++){
						switch (oMsg.basis[iM].mode){
							case 0:
								this.printer.write(", at row " + TEXTMAP_AD_ROW[oMsg.basis[iM].pointer]);
								break;
							case 1:
								this.printer.write(", at column " + TEXTMAP_AD_COL[oMsg.basis[iM].pointer]);
								break;
							case 2:
								this.printer.write(", at box " + TEXTMAP_AD_BOX[oMsg.basis[iM].pointer]);
								break;
						}
					}
					this.printer.newline();
					aRemoved = oMsg.removed;
					for (var iM = 0; aRemoved.length > iM; iM++){
						this.printer.writeln("-> " + _candistr(aRemoved[iM].candi) + " taken from " + aRemoved[iM].adstr());
					}
				}
			}
			if (oUr.redraw){
				this.canvas.write(oUr.puzzle);
				var oMsg;
				var aRemoved;
				for (var iN = 0; oUr.messages.length > iN; iN++){
					oMsg = oUr.messages[iN];
					this.canvas.highlight(oMsg.candi1.ad, oMsg.candi1.candi, "pzh_basis");
					this.canvas.highlight(oMsg.candi2.ad, oMsg.candi2.candi, "pzh_basis");
					aRemoved = oMsg.removed;
					for (var iM = 0; aRemoved.length > iM; iM++){
						this.canvas.highlight(aRemoved[iM].ad, aRemoved[iM].candi, "pzh_remove");
					}
				}
			}
			this.autoNextStep();
			return false;
			
		case UR_NAKED3:
			if (oUr.inform){
				this.printer.append($("<div>").addClass("stg_title2").text("Step #" + this.step + " : Naked Triple"));
				this.printer.newline();
				var oMsg;
				var aRemoved;
				for (var iN = 0; oUr.messages.length > iN; iN++){
					oMsg = oUr.messages[iN];
					this.printer.write(_candistr(oMsg.candi1.candi | oMsg.candi2.candi | oMsg.candi3.candi)
						 + "@[" + oMsg.candi1.adstr() + "|" + oMsg.candi2.adstr() + "|" + oMsg.candi3.adstr() + "]");
					for (var iM = 0; oMsg.basis.length > iM; iM++){
						switch (oMsg.basis[iM].mode){
							case 0:
								this.printer.write(", at row " + TEXTMAP_AD_ROW[oMsg.basis[iM].pointer]);
								break;
							case 1:
								this.printer.write(", at column " + TEXTMAP_AD_COL[oMsg.basis[iM].pointer]);
								break;
							case 2:
								this.printer.write(", at box " + TEXTMAP_AD_BOX[oMsg.basis[iM].pointer]);
								break;
						}
					}
					this.printer.newline();
					aRemoved = oMsg.removed;
					for (var iM = 0; aRemoved.length > iM; iM++){
						this.printer.writeln("-> " + _candistr(aRemoved[iM].candi) + " taken from " + aRemoved[iM].adstr());
					}
				}
			}
			if (oUr.redraw){
				this.canvas.write(oUr.puzzle);
				var oMsg;
				var aRemoved;
				for (var iN = 0; oUr.messages.length > iN; iN++){
					oMsg = oUr.messages[iN];
					this.canvas.highlight(oMsg.candi1.ad, oMsg.candi1.candi, "pzh_basis");
					this.canvas.highlight(oMsg.candi2.ad, oMsg.candi2.candi, "pzh_basis");
					this.canvas.highlight(oMsg.candi3.ad, oMsg.candi3.candi, "pzh_basis");
					aRemoved = oMsg.removed;
					for (var iM = 0; aRemoved.length > iM; iM++){
						this.canvas.highlight(aRemoved[iM].ad, aRemoved[iM].candi, "pzh_remove");
					}
				}
			}
			this.autoNextStep();
			return false;
			
		case UR_NAKED4:
			if (oUr.inform){
				this.printer.append($("<div>").addClass("stg_title2").text("Step #" + this.step + " : Naked Quadraple"));
				this.printer.newline();
				var oMsg;
				var aRemoved;
				for (var iN = 0; oUr.messages.length > iN; iN++){
					oMsg = oUr.messages[iN];
					this.printer.write(_candistr(oMsg.candi1.candi | oMsg.candi2.candi | oMsg.candi3.candi | oMsg.candi4.candi)
						 + "@[" + oMsg.candi1.adstr() + "|" + oMsg.candi2.adstr() + "|" + oMsg.candi3.adstr() + "|" + oMsg.candi4.adstr() + "]");
					for (var iM = 0; oMsg.basis.length > iM; iM++){
						switch (oMsg.basis[iM].mode){
							case 0:
								this.printer.write(", at row " + TEXTMAP_AD_ROW[oMsg.basis[iM].pointer]);
								break;
							case 1:
								this.printer.write(", at column " + TEXTMAP_AD_COL[oMsg.basis[iM].pointer]);
								break;
							case 2:
								this.printer.write(", at box " + TEXTMAP_AD_BOX[oMsg.basis[iM].pointer]);
								break;
						}
					}
					this.printer.newline();
					aRemoved = oMsg.removed;
					for (var iM = 0; aRemoved.length > iM; iM++){
						this.printer.writeln("-> " + _candistr(aRemoved[iM].candi) + " taken from " + aRemoved[iM].adstr());
					}
				}
			}
			if (oUr.redraw){
				this.canvas.write(oUr.puzzle);
				var oMsg;
				var aRemoved;
				for (var iN = 0; oUr.messages.length > iN; iN++){
					oMsg = oUr.messages[iN];
					this.canvas.highlight(oMsg.candi1.ad, oMsg.candi1.candi, "pzh_basis");
					this.canvas.highlight(oMsg.candi2.ad, oMsg.candi2.candi, "pzh_basis");
					this.canvas.highlight(oMsg.candi3.ad, oMsg.candi3.candi, "pzh_basis");
					this.canvas.highlight(oMsg.candi4.ad, oMsg.candi4.candi, "pzh_basis");
					aRemoved = oMsg.removed;
					for (var iM = 0; aRemoved.length > iM; iM++){
						this.canvas.highlight(aRemoved[iM].ad, aRemoved[iM].candi, "pzh_remove");
					}
				}
			}
			this.autoNextStep();
			return false;
