/* ***********************************************
	Strategy : Naked Group 
*********************************************** */
var oStgNakedSet = new NodeObject();

oStgNakedSet.onsolverequest = function(oSr){
	var oPz = oSr.puzzle;
	var oUr = new UpdateRequest(UR_NONE, oPz);
	var iSetSize = oUr.setSize || this.setSize;
	var aMsgs = [];

	// Loop for mode : row / column / box
	for (var iMode = 0; 3 > iMode; iMode++){
		// Loop for each logical unit in the given mod
		for (var iPtrLu = 0; SDK_ORDER > iPtrLu; iPtrLu++){
			var apLu;
			switch (iMode){
			case 0 :
				apLu = LU_ROW_DATA[iPtrLu];
				break;
			case 1 :
				apLu = LU_COL_DATA[iPtrLu];
				break;
			case 2 :
				apLu = LU_BOX_DATA[iPtrLu];
				break;
			}
			// Create a list of n-sets
			var aListSets = [];
			for (var iPtr = 0; SDK_ORDER > iPtr; iPtr++){
				var iAd = apLu[iPtr];
				if (oPz.cell[iAd].size > 1 || oPz.cell[iAd].size <= iGpSize){
					aSets.push(iAd);
				}
			}
			var iListSize = aListSets.length;
			var aSubs;
			switch (iSetSize){
			case 2:
				aSubs = LU_SUBS2[iListSize];
				break;
			case 3:
				aSubs = LU_SUBS3[iListSize];
				break;
			case 4:
				aSubs = LU_SUBS4[iListSize];
				break;
			}
			// Perform check
			var iFt = 0, iFtCommon = 0;
			var iAd1 = 0, iAd2 = 0, iAd3 = 0, iAd4 = 0;
			for (var iPptr = 0; aSubs.length > iPptr; iPptr++){
				var iFt = oPz.data[iAd1 = apLu[aSubs[iPptr][0]]];
				switch (iSetSize){
				case 4:
					iFt |= oPz.data[iAd2 = apLu[aSubs[iPptr][3]]];
				case 3:
					iFt |= oPz.data[iAd3 = apLu[aSubs[iPptr][2]]];
				case 2:
					iFt |= oPz.data[iAd4 = apLu[aSubs[iPptr][1]]];
				}
				if (_size(iFt) > iSetSize){
					continue;
				}
				// If a naked subset of order n is formed,
				var aRemoved = [];
				for (var iPtr = 0; SDK_ORDER > iPtr; iPtr++){
					// Avoid self-referencing
					var iAd = apLu[iPtr];
					if (iAd == iAd1){
						continue;
					}
					else if (iSetSize > 1 && iAd == iAd2){
						continue;
					}
					else if (iSetSize > 2 && iAd == iAd3){
						continue;
					}
					else if (iSetSize > 3 && iAd == iAd4){
						continue;
					}
					// if the cell shares a common candidate with the n-subset
					if (iFtCommon = iFt & oPz.data[iAd]){
						aRemoved.push(new Candi(iAd, iFtCommon));
					}
				} // End of Loop : elimination
				if (aRemoved.length){
					var oBasis = { mode : iMode, pointer : iPtrLu };
					var bExists = false;
					var aCandi = [new Candi(iAd1, oPz.data[iAd1])];
					if (iSetSize > 1){
						aCandi.push(new Candi(iAd2, oPz.data[iAd2]));
					}
					if (iSetSize > 2){
						aCandi.push(new Candi(iAd3, oPz.data[iAd3]));
					}
					if (iSetSize > 3){
						aCandi.push(new Candi(iAd4, oPz.data[iAd4]));
					}
					for (var iM = 0; aMsgs.length > iM; iM++){
						if (aMsgs[iM].candi[0].ad != iAd1){
							continue;
						}
						else if (iSetSize > 1 && aMsgs[iM].candi[1].ad != iAd2){
							continue;
						}
						else if (iSetSize > 2 && aMsgs[iM].candi[2].ad != iAd3){
							continue;
						}
						else if (iSetSize > 3 && aMsgs[iM].candi[3].ad != iAd4){
							continue;
						}
						else {
							bExists = true;
							aMsgs[iM].basis.push(oBasis);
							add_next :
							for (var iL = 0; aRemoved.length > iL; iL++){
								for (var iK = 0; aMsgs[iM].removed.length > iK; iK++){
									if (aRemoved[iL].ad == aMsgs[iM].removed[iK].ad){
										continue add_next;
									}
								}
								aMsgs[iM].removed.push(aRemoved[iL]);
							}
							break;
						}
					}
					if (!bExists){
						aMsgs.push({
							basis : [oBasis], 
							candi : aCandi,
							removed : aRemoved
						});
					}
				}

	if (aMsgs.length){
		switch (iSetSize){
		case 2:
			oUr.type = UR_NAKED2;
			break;
		case 3:
			oUr.type = UR_NAKED3;
			break;
		case 4:
			oUr.type = UR_NAKED4;
			break;
		}
		oUr.messages = aMsgs;
		oUr.action = this.actionDetermine;
	}
	this.parent.updaterequest(oUr);
	return false;
};

oStgNakedSet.actionDetermine = function(){
	var oPz = this.puzzle;
	var aRemoved;
	for (var iN = 0; this.messages.length > iN; iN++){
		aRemoved = this.messages[iN].removed;
		for (var iM = 0; aRemoved.length > iM; iM++){
			oPz.data[aRemoved[iM].ad] &= ~aRemoved[iM].candi;
			oPz.cell[aRemoved[iM].ad].update(true);
		}
	}
};