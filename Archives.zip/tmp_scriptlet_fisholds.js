/* ***********************************************
	Strategy : X-Wing 
*********************************************** */
var oStgXWing = new NodeObject();

oStgXWing.onsolverequest = function(oSr){
	var oPz = oSr.puzzle;
	var oUr = new UpdateRequest(UR_NONE, oPz);
	var oMsg = null;

	// Loop for mode : row / column
	main_loop :
	for (var iMode = 0; 2 > iMode; iMode++){
		// Loop for each value
		for (var iValue = 1; SDK_ORDER >= iValue; iValue++){
			var iFt = 1 << iValue;

			// Create a list of bi-valued logical unit
			var aBivalued = [];
			var aRef = null;
			switch (iMode){
				case 0 :
					aRef = LU_ROW_DATA;
					break;
				case 1:
					aRef = LU_COL_DATA;
					break;
			}
			
			for (var iPtrLu = 0; SDK_ORDER > iPtrLu; iPtrLu++){
				var iCount = 0;
				var iData = 0;
				for (var iPtr = 0; SDK_ORDER > iPtr; iPtr++){
					if (oPz.data[aRef[iPtrLu][iPtr]] & iFt){
						iCount++;
						iData |= (1 << iPtr);
					}
				}
				if (iCount == 2){
					aBivalued.push({ pointer : iPtrLu, data : iData });
				}
			}

			// Loop for the first bi-valued logical unit
			for (var iPtr1 = 0; aBivalued.length > iPtr1; iPtr1++){
				var iData = aBivalued[iPtr1].data;
				// Loop for the second bi-valued logical unit
				for (var iPtr2 = iPtr1+1; aBivalued.length > iPtr2; iPtr2++){
					if (iData != aBivalued[iPtr2].data){
						continue;
					}
					// If two parallel logical units match the X-wing condition
					// Loop for the elimination
					// Perpenticular pointers
					var aPtrs = [];
					for (var iPtr = 0; SDK_ORDER > iPtr; iPtr++){
						if (iData & (1 << iPtr)){
							aPtrs.push(iPtr);
						}
					}
					oMsg = {
						mode : iMode,
						value : iValue,
						basis : [],
						removed : []
					};
					
					var aPerpRef = null;
					switch (iMode){
						case 0 :
							aPerpRef = LU_COL_DATA;
							break;
						case 1:
							aPerpRef = LU_ROW_DATA;
							break;
					}
					// Loop for each perpendicular logical unit
					for (var iPptr = 0; aPtrs.length > iPptr; iPptr++){
						// Loop for each parallel cross
						for (var iPtrLu = 0; SDK_ORDER > iPtrLu; iPtrLu++){
							var iAd = aPerpRef[aPtrs[iPptr]][iPtrLu];
							var iFtRes = iFt & oPz.data[iAd];
							if (iPtrLu == aBivalued[iPtr1].pointer || iPtrLu == aBivalued[iPtr2].pointer){
								oMsg.basis.push(new Candi(iAd, iFtRes));
								continue;
							}
							// Remove the wing!
							if (iFtRes){
								oMsg.removed.push(new Candi(iAd, iFtRes));
							}
						}
					}
					
					if (oMsg.removed.length){
						break main_loop;
					}
					else {
						oMsg = null;
					}
				} // End of Loop : 2nd bi-valued logical unit
			} // End of Loop : 1st bi-valued logical unit
		} // End of Loop : value
	} // End of Loop : mode

	if (oMsg){
		oUr.type = UR_XWING;
		oUr.message = oMsg;
		oUr.action = this.actionDetermine;
	}
	this.parent.updaterequest(oUr);
	return false;
};

oStgXWing.actionDetermine = function(){
	var oPz = this.puzzle;
	var aRemoved = this.message.removed;
	for (var iM = 0; aRemoved.length > iM; iM++){
		oPz.data[aRemoved[iM].ad] &= ~aRemoved[iM].candi;
		oPz.cell[aRemoved[iM].ad].update(true);
	}
};

/* ***********************************************
	Strategy : Swordfish 
*********************************************** */
var oStgSwordfish = new NodeObject();

oStgSwordfish.onsolverequest = function(oSr){
	var oPz = oSr.puzzle;
	var oUr = new UpdateRequest(UR_NONE, oPz);
	var oMsg = null;

	// Loop for mode : row / column
	main_loop :
	for (var iMode = 0; 2 > iMode; iMode++){
		// Loop for each value
		for (var iValue = 1; SDK_ORDER >= iValue; iValue++){
			var iFt = 1 << iValue;

			// Create a list of tri-valued logical unit
			var aTrivalued = [];
			var aRef = null;
			switch (iMode){
				case 0 :
					aRef = LU_ROW_DATA;
					break;
				case 1:
					aRef = LU_COL_DATA;
					break;
			}
			
			for (var iPtrLu = 0; SDK_ORDER > iPtrLu; iPtrLu++){
				var iCount = 0;
				var iData = 0;
				for (var iPtr = 0; SDK_ORDER > iPtr; iPtr++){
					if (oPz.data[aRef[iPtrLu][iPtr]] & iFt){
						iCount++;
						iData |= (1 << iPtr);
					}
				}
				if (iCount == 2 || iCount == 3){
					aTrivalued.push({ pointer : iPtrLu, data : iData });
				}
			}

			// Loop for the first tri-valued logical unit
			for (var iPtr1 = 0; aTrivalued.length > iPtr1; iPtr1++){
				var iData1 = aTrivalued[iPtr1].data;
				// Loop for the second tri-valued logical unit
				for (var iPtr2 = iPtr1+1; aTrivalued.length > iPtr2; iPtr2++){
					var iData2 = iData1 | aTrivalued[iPtr2].data;
					if (_size(iData2 << 1) > 3){
						continue;
					}
					// Loop for the second tri-valued logical unit
					for (var iPtr3 = iPtr2+1; aTrivalued.length > iPtr3; iPtr3++){
						var iData3 = iData2 | aTrivalued[iPtr3].data;
						if (_size(iData3 << 1) > 3){
							continue;
						}
						// If three parallel logical units match the Swordfish condition
						// Loop for the elimination
						// Perpenticular pointers
						var aPtrs = [];
						for (var iPtr = 0; SDK_ORDER > iPtr; iPtr++){
							if (iData3 & (1 << iPtr)){
								aPtrs.push(iPtr);
							}
						}
						oMsg = {
							mode : iMode,
							value : iValue,
							basis : [],
							removed : []
						};
						
						var aPerpRef = null;
						switch (iMode){
							case 0 :
								aPerpRef = LU_COL_DATA;
								break;
							case 1:
								aPerpRef = LU_ROW_DATA;
								break;
						}
						// Loop for each perpendicular logical unit
						for (var iPptr = 0; aPtrs.length > iPptr; iPptr++){
							// Loop for each parallel cross
							for (var iPtrLu = 0; SDK_ORDER > iPtrLu; iPtrLu++){
								var iAd = aPerpRef[aPtrs[iPptr]][iPtrLu];
								var iFtRes = iFt & oPz.data[iAd];
								if (iPtrLu == aTrivalued[iPtr1].pointer || iPtrLu == aTrivalued[iPtr2].pointer || iPtrLu == aTrivalued[iPtr3].pointer){
									oMsg.basis.push(new Candi(iAd, iFtRes));
									continue;
								}
								// Remove the wing!
								if (iFtRes){
									oMsg.removed.push(new Candi(iAd, iFtRes));
								}
							}
						}
						
						if (oMsg.removed.length){
							break main_loop;
						}
						else {
							oMsg = null;
						}
					} // End of Loop : 3rd tri-valued logical unit
				} // End of Loop : 2nd tri-valued logical unit
			} // End of Loop : 1st tri-valued logical unit
		} // End of Loop : value
	} // End of Loop : mode

	if (oMsg){
		oUr.type = UR_SWORDFISH;
		oUr.message = oMsg;
		oUr.action = this.actionDetermine;
	}
	this.parent.updaterequest(oUr);
	return false;
};

oStgSwordfish.actionDetermine = function(){
	var oPz = this.puzzle;
	var aRemoved = this.message.removed;
	for (var iM = 0; aRemoved.length > iM; iM++){
		oPz.data[aRemoved[iM].ad] &= ~aRemoved[iM].candi;
		oPz.cell[aRemoved[iM].ad].update(true);
	}
};

/* ***********************************************
	Strategy : Jellyfish 
*********************************************** */
var oStgJellyfish = new NodeObject();

oStgJellyfish.onsolverequest = function(oSr){
	var oPz = oSr.puzzle;
	var oUr = new UpdateRequest(UR_NONE, oPz);
	var oMsg = null;

	// Loop for mode : row / column
	main_loop :
	for (var iMode = 0; 2 > iMode; iMode++){
		// Loop for each value
		for (var iValue = 1; SDK_ORDER >= iValue; iValue++){
			var iFt = 1 << iValue;

			// Create a list of tri-valued logical unit
			var aQuadvalued = [];
			var aRef = null;
			switch (iMode){
				case 0 :
					aRef = LU_ROW_DATA;
					break;
				case 1:
					aRef = LU_COL_DATA;
					break;
			}
			
			for (var iPtrLu = 0; SDK_ORDER > iPtrLu; iPtrLu++){
				var iCount = 0;
				var iData = 0;
				for (var iPtr = 0; SDK_ORDER > iPtr; iPtr++){
					if (oPz.data[aRef[iPtrLu][iPtr]] & iFt){
						iCount++;
						iData |= (1 << iPtr);
					}
				}
				if (iCount == 2 || iCount == 3 || iCount == 4){
					aQuadvalued.push({ pointer : iPtrLu, data : iData });
				}
			}

			// Loop for the first tri-valued logical unit
			for (var iPtr1 = 0; aQuadvalued.length > iPtr1; iPtr1++){
				var iData1 = aQuadvalued[iPtr1].data;
				// Loop for the second tri-valued logical unit
				for (var iPtr2 = iPtr1+1; aQuadvalued.length > iPtr2; iPtr2++){
					var iData2 = iData1 | aQuadvalued[iPtr2].data;
					if (_size(iData2 << 1) > 4){
						continue;
					}
					// Loop for the second tri-valued logical unit
					for (var iPtr3 = iPtr2+1; aQuadvalued.length > iPtr3; iPtr3++){
						var iData3 = iData2 | aQuadvalued[iPtr3].data;
						if (_size(iData3 << 1) > 4){
							continue;
						}
						for (var iPtr4 = iPtr3+1; aQuadvalued.length > iPtr4; iPtr4++){
							var iData4 = iData3 | aQuadvalued[iPtr4].data;
							if (_size(iData4 << 1) > 4){
								continue;
							}
							// If three parallel logical units match the Swordfish condition
							// Loop for the elimination
							// Perpenticular pointers
							var aPtrs = [];
							for (var iPtr = 0; SDK_ORDER > iPtr; iPtr++){
								if (iData4 & (1 << iPtr)){
									aPtrs.push(iPtr);
								}
							}
							oMsg = {
								mode : iMode,
								value : iValue,
								basis : [],
								removed : []
							};
							
							var aPerpRef = null;
							switch (iMode){
								case 0 :
									aPerpRef = LU_COL_DATA;
									break;
								case 1:
									aPerpRef = LU_ROW_DATA;
									break;
							}
							// Loop for each perpendicular logical unit
							for (var iPptr = 0; aPtrs.length > iPptr; iPptr++){
								// Loop for each parallel cross
								for (var iPtrLu = 0; SDK_ORDER > iPtrLu; iPtrLu++){
									var iAd = aPerpRef[aPtrs[iPptr]][iPtrLu];
									var iFtRes = iFt & oPz.data[iAd];
									if (iPtrLu == aQuadvalued[iPtr1].pointer
										|| iPtrLu == aQuadvalued[iPtr2].pointer
										|| iPtrLu == aQuadvalued[iPtr3].pointer
										|| iPtrLu == aQuadvalued[iPtr4].pointer){
										oMsg.basis.push(new Candi(iAd, iFtRes));
										continue;
									}
									// Remove the wing!
									if (iFtRes){
										oMsg.removed.push(new Candi(iAd, iFtRes));
									}
								}
							}
							
							if (oMsg.removed.length){
								break main_loop;
							}
							else {
								oMsg = null;
							}
						} // End of Loop : 4th quad-valued logical unit
					} // End of Loop : 3rd quad-valued logical unit
				} // End of Loop : 2nd quad-valued logical unit
			} // End of Loop : 1st quad-valued logical unit
		} // End of Loop : value
	} // End of Loop : mode

	if (oMsg){
		oUr.type = UR_JELLYFISH;
		oUr.message = oMsg;
		oUr.action = this.actionDetermine;
	}
	this.parent.updaterequest(oUr);
	return false;
};

oStgJellyfish.actionDetermine = function(){
	var oPz = this.puzzle;
	var aRemoved = this.message.removed;
	for (var iM = 0; aRemoved.length > iM; iM++){
		oPz.data[aRemoved[iM].ad] &= ~aRemoved[iM].candi;
		oPz.cell[aRemoved[iM].ad].update(true);
	}
};